"use strict";
(() => {
  // src/visibility-override.ts
  (function() {
    let active = false;
    const originalHiddenDescriptor = Object.getOwnPropertyDescriptor(
      Document.prototype,
      "hidden"
    );
    const originalVisibilityStateDescriptor = Object.getOwnPropertyDescriptor(
      Document.prototype,
      "visibilityState"
    );
    Object.defineProperty(document, "hidden", {
      configurable: true,
      get() {
        if (active)
          return false;
        return originalHiddenDescriptor.get.call(this);
      }
    });
    Object.defineProperty(document, "visibilityState", {
      configurable: true,
      get() {
        if (active)
          return "visible";
        return originalVisibilityStateDescriptor.get.call(this);
      }
    });
    document.addEventListener(
      "visibilitychange",
      (e) => {
        if (active) {
          e.stopImmediatePropagation();
        }
      },
      true
    );
    window.addEventListener("tokative-visibility-override", (e) => {
      active = e.detail.active;
    });
  })();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL3Zpc2liaWxpdHktb3ZlcnJpZGUudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKiBNYWluLXdvcmxkIHNjcmlwdCBpbmplY3RlZCBhdCBkb2N1bWVudF9zdGFydCB0byBzcG9vZiBQYWdlIFZpc2liaWxpdHkgQVBJLlxuICogIFdoZW4gYWN0aXZlLCBUaWtUb2sgYmVsaWV2ZXMgdGhlIHRhYiBpcyBhbHdheXMgdmlzaWJsZSBzbyBpdCBjb250aW51ZXNcbiAqICBsYXp5LWxvYWRpbmcgY29tbWVudHMgZXZlbiB3aGVuIHRoZSB0YWIgaXMgaW4gdGhlIGJhY2tncm91bmQuXG4gKiAgVG9nZ2xlZCBieSBjb250ZW50IHNjcmlwdCB2aWEgQ3VzdG9tRXZlbnQuICovXG5cbihmdW5jdGlvbiAoKSB7XG4gIGxldCBhY3RpdmUgPSBmYWxzZTtcblxuICBjb25zdCBvcmlnaW5hbEhpZGRlbkRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKFxuICAgIERvY3VtZW50LnByb3RvdHlwZSxcbiAgICBcImhpZGRlblwiLFxuICApITtcbiAgY29uc3Qgb3JpZ2luYWxWaXNpYmlsaXR5U3RhdGVEZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihcbiAgICBEb2N1bWVudC5wcm90b3R5cGUsXG4gICAgXCJ2aXNpYmlsaXR5U3RhdGVcIixcbiAgKSE7XG5cbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRvY3VtZW50LCBcImhpZGRlblwiLCB7XG4gICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIGdldCgpIHtcbiAgICAgIGlmIChhY3RpdmUpIHJldHVybiBmYWxzZTtcbiAgICAgIHJldHVybiBvcmlnaW5hbEhpZGRlbkRlc2NyaXB0b3IuZ2V0IS5jYWxsKHRoaXMpO1xuICAgIH0sXG4gIH0pO1xuXG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShkb2N1bWVudCwgXCJ2aXNpYmlsaXR5U3RhdGVcIiwge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBnZXQoKSB7XG4gICAgICBpZiAoYWN0aXZlKSByZXR1cm4gXCJ2aXNpYmxlXCI7XG4gICAgICByZXR1cm4gb3JpZ2luYWxWaXNpYmlsaXR5U3RhdGVEZXNjcmlwdG9yLmdldCEuY2FsbCh0aGlzKTtcbiAgICB9LFxuICB9KTtcblxuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFxuICAgIFwidmlzaWJpbGl0eWNoYW5nZVwiLFxuICAgIChlKSA9PiB7XG4gICAgICBpZiAoYWN0aXZlKSB7XG4gICAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgICB9XG4gICAgfSxcbiAgICB0cnVlLFxuICApO1xuXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwidG9rYXRpdmUtdmlzaWJpbGl0eS1vdmVycmlkZVwiLCAoKFxuICAgIGU6IEN1c3RvbUV2ZW50PHsgYWN0aXZlOiBib29sZWFuIH0+LFxuICApID0+IHtcbiAgICBhY3RpdmUgPSBlLmRldGFpbC5hY3RpdmU7XG4gIH0pIGFzIEV2ZW50TGlzdGVuZXIpO1xufSkoKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQUtBLEdBQUMsV0FBWTtBQUNYLFFBQUksU0FBUztBQUViLFVBQU0sMkJBQTJCLE9BQU87QUFBQSxNQUN0QyxTQUFTO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQSxVQUFNLG9DQUFvQyxPQUFPO0FBQUEsTUFDL0MsU0FBUztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsV0FBTyxlQUFlLFVBQVUsVUFBVTtBQUFBLE1BQ3hDLGNBQWM7QUFBQSxNQUNkLE1BQU07QUFDSixZQUFJO0FBQVEsaUJBQU87QUFDbkIsZUFBTyx5QkFBeUIsSUFBSyxLQUFLLElBQUk7QUFBQSxNQUNoRDtBQUFBLElBQ0YsQ0FBQztBQUVELFdBQU8sZUFBZSxVQUFVLG1CQUFtQjtBQUFBLE1BQ2pELGNBQWM7QUFBQSxNQUNkLE1BQU07QUFDSixZQUFJO0FBQVEsaUJBQU87QUFDbkIsZUFBTyxrQ0FBa0MsSUFBSyxLQUFLLElBQUk7QUFBQSxNQUN6RDtBQUFBLElBQ0YsQ0FBQztBQUVELGFBQVM7QUFBQSxNQUNQO0FBQUEsTUFDQSxDQUFDLE1BQU07QUFDTCxZQUFJLFFBQVE7QUFDVixZQUFFLHlCQUF5QjtBQUFBLFFBQzdCO0FBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBRUEsV0FBTyxpQkFBaUIsZ0NBQWlDLENBQ3ZELE1BQ0c7QUFDSCxlQUFTLEVBQUUsT0FBTztBQUFBLElBQ3BCLENBQW1CO0FBQUEsRUFDckIsR0FBRzsiLAogICJuYW1lcyI6IFtdCn0K
