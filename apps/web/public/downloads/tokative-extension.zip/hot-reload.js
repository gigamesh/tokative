
(function() {
  if (typeof window === 'undefined') return;

  let retryCount = 0;
  const maxRetries = 5;

  function connectWebSocket() {
    try {
      const ws = new WebSocket('ws://localhost:8080');

      ws.onopen = () => {
        console.log('[Tokative] Hot reload connected');
        retryCount = 0;
      };

      ws.onmessage = (event) => {
        if (event.data === 'reload') {
          console.log('[Tokative] Reloading...');
          chrome.runtime.sendMessage({ type: 'HOT_RELOAD' });
          window.location.reload();
        }
      };

      ws.onerror = () => {
        console.log('[Tokative] Hot reload connection error');
      };

      ws.onclose = () => {
        if (retryCount < maxRetries) {
          retryCount++;
          console.log('[Tokative] Hot reload disconnected, retrying (' + retryCount + '/' + maxRetries + ')...');
          setTimeout(connectWebSocket, Math.min(1000 * retryCount, 5000));
        } else {
          console.log('[Tokative] Hot reload disabled');
        }
      };
    } catch (e) {
      console.log('[Tokative] Hot reload not available');
    }
  }

  if (window.location.hostname === 'www.tiktok.com' || window.location.hostname === 'localhost') {
    connectWebSocket();
  }
})();
